import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
//import { SignupPage } from '../signup/signup';
import { LoginPage } from '../login/login';
import { CodepagePage } from '../codepage/codepage';
import { ConfirmsignPage } from '../confirmsign/confirmsign';
import { RetimePage } from '../retime/retime';
import { NeworderPage } from '../neworder/neworder';
import { PatientreviewPage } from '../patientreview/patientreview';
import { CurrentorderPage } from '../currentorder/currentorder';
import { LoginServiceProvider } from '../../providers/login-service/login-service';
import { HelperProvider } from '../../providers/helper/helper';
import { Storage } from '@ionic/storage';
@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
  lang_direction= ""
  ratingStatus = 4
  userOrders = []
  constructor(public navCtrl: NavController, public helper: HelperProvider,
    public doctor_service: LoginServiceProvider, public storage: Storage) {
      this.lang_direction = this.helper.lang_direction;
  }
  doRefresh(refresher) {
    this.ionViewDidEnter();
    refresher.complete();
  }
  ionViewDidEnter(){
    this.storage.get("user_login_token").then((val)=> {
      this.doctor_service.getUserOrders(1,val.access_token, (data)=> {
        this.userOrders = data
      }, (data)=> {

      })
    })
    
  }

  retime(){
    this.navCtrl.push(RetimePage)
  }

  currentor(){
    this.navCtrl.push(CurrentorderPage)
  }
  patientrev(){
    this.navCtrl.push(PatientreviewPage)
  }
  neworder()
  {
    this.navCtrl.push(NeworderPage)
  }
sign()
{
//  this.navCtrl.push(SignupPage)
}
login()
{
  this.navCtrl.push(LoginPage)

}
code()
{
  this.navCtrl.push(CodepagePage)
}
confirm()
{
  this.navCtrl.push(ConfirmsignPage)
}
}
