import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NeworderPage } from './neworder';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    NeworderPage,
  ],
  imports: [
    IonicPageModule.forChild(NeworderPage),
    TranslateModule.forChild(),
  ],
})
export class NeworderPageModule {}
