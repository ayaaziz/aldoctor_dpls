import { Component } from '@angular/core';

import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';
import { HomePage } from '../home/home';
import { NotificationPage } from '../notification/notification';
import { Events} from 'ionic-angular';


@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
  notiCount = 0
  tab1Root = HomePage;
  tab2Root = AboutPage;
  tab3Root = ContactPage;
  tab4Root = NotificationPage;

  constructor(public events: Events) {
    this.events.subscribe('lengthdata', (count) => {
      
      this.notiCount = count;
  });
  }
  
}
