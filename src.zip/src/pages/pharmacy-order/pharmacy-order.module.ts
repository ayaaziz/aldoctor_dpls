import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PharmacyOrderPage } from './pharmacy-order';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    PharmacyOrderPage,
  ],
  imports: [
    IonicPageModule.forChild(PharmacyOrderPage),
    TranslateModule.forChild(),
  ],
})
export class PharmacyOrderPageModule {}
