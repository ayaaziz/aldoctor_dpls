import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CenterOrderPage } from './center-order';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    CenterOrderPage,
  ],
  imports: [
    IonicPageModule.forChild(CenterOrderPage),
    TranslateModule.forChild(),
  ],
})
export class CenterOrderPageModule {}
